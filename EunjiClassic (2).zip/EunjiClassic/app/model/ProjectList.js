// Ext.define('EunjiClassic.model.ProjectList', {
//     extend: 'EunjiClassic.model.Base',

//     fields: [
//         'Title', 'StartDate', 'EndDate', 'Status', 'Description', 'MenuTemplate', 'Manager', 'Period', 'Issue'
//     ]
// });
