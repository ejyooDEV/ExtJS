Ext.define('EunjiClassic.model.Base', {
    extend: 'Ext.data.Model',

    schema: {
        namespace: 'EunjiClassic.model'
    }
});
