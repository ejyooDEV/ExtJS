Ext.define('EunjiClassic.view.second.common.window.WindowModel',{
    //extend: 'EunjiClassic.view.page.ProjectMainModel',
    extend:'Ext.app.ViewModel',
    alias: 'viewmodel.nodewindow',

    
});