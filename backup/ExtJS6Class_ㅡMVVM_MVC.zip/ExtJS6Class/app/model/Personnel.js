Ext.define('ExtJS6Class.model.Personnel', {
    extend: 'ExtJS6Class.model.Base',

    fields: [
        'name', 'email', 'phone'
    ]
});
