Ext.define("Ext.locale.it.data.validator.Format", {
    override: "Ext.data.validator.Format",

    message: "E' nel formato errato"
});
