Ext.define("Ext.locale.it.grid.RowEditor", {
    override: "Ext.grid.RowEditor",

    saveBtnText: 'Invia',
    cancelBtnText: 'Annulla',
    errorsText: 'Errori',
    dirtyText: 'Confermare o annullare i cambiamenti'
});
