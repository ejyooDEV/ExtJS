Ext.define("Ext.locale.it.grid.column.Number", {
    override: "Ext.grid.column.Number",

    format: '0.000,00'
});
