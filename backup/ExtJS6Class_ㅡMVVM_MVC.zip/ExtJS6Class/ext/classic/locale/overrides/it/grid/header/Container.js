Ext.define("Ext.locale.it.grid.header.Container", {
    override: "Ext.grid.header.Container",

    sortAscText: "Ordinamento Crescente",
    sortDescText: "Ordinamento Decrescente",
    sortClearText: "Senza Ordinamento naturale",
    columnsText: "Colonne"
});
