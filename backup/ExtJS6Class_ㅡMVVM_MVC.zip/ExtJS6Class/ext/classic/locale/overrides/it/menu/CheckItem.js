Ext.define("Ext.locale.it.menu.CheckItem", {
    override: 'Ext.menu.CheckItem',

    submenuText: '{0} sottomenu'
});
