Ext.define("Ext.locale.it.picker.Month", {
    override: "Ext.picker.Month",

    okText: 'OK',
    cancelText: 'Annulla'
});
