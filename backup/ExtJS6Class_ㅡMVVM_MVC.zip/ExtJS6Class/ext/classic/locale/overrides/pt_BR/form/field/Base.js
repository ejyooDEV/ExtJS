Ext.define("Ext.locale.pt_BR.form.field.Base", {
    override: "Ext.form.field.Base",
    invalidText: "O valor para este campo é inválido"
});
