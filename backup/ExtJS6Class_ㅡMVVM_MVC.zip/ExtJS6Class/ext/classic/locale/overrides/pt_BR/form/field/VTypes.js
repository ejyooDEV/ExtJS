Ext.define("Ext.locale.pt_BR.form.field.VTypes", {
    override: "Ext.form.field.VTypes",
    emailText: 'Este campo deve ser um endereço de e-mail válido, no formato "usuario@dominio.com.br"',
    urlText: 'Este campo deve ser uma URL no formato "http:/' + '/www.dominio.com.br"',
    alphaText: 'Este campo deve conter apenas letras e _',
    alphanumText: 'Este campo deve conter apenas letras, números e _'
});
