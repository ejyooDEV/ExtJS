Ext.define('Ext.locale.pt_BR.grid.header.Container', {
    override: 'Ext.grid.header.Container',
    sortAscText: 'Ordem Ascendente',
    sortDescText: 'Ordem Descendente',
    columnsText: 'Colunas'
});
