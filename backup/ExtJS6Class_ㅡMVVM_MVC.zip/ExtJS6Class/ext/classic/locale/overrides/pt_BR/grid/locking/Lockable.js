Ext.define('Ext.locale.pt_BR.grid.locking.Lockable', {
    override: 'Ext.grid.locking.Lockable',
    lockText: 'Bloquear Coluna',
    unlockText: 'Desbloquear Coluna'
});
