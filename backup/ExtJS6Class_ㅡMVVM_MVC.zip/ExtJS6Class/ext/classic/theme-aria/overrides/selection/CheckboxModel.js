Ext.define('Ext.theme.aria.selection.CheckboxModel', {
    override: 'Ext.selection.CheckboxModel',

    headerWidth: 28
});
