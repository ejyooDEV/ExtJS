cur_dir = File.dirname(__FILE__)
output_style = :nested
