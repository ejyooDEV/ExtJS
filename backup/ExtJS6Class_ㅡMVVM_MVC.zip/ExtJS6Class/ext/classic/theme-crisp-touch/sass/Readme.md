# theme-crisp-touch/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    theme-crisp-touch/sass/etc
    theme-crisp-touch/sass/src
    theme-crisp-touch/sass/var
