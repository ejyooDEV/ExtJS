Ext.define('Ext.theme.triton.grid.column.RowNumberer', {
    override: 'Ext.grid.column.RowNumberer',

    width: 32
});
