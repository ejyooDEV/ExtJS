Ext.define('Ext.theme.triton.toolbar.Paging', {
    override: 'Ext.toolbar.Paging',
    inputItemWidth: 50
});
