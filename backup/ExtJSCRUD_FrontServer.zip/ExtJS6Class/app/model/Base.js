Ext.define('ExtJS6Class.model.Base', {
    extend: 'Ext.data.Model',

    schema: {
        namespace: 'ExtJS6Class.model'
    }
});
