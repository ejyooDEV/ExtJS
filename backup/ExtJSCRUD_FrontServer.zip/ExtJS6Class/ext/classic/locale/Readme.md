# locale

Locale package for Classic toolkit. Right now it supports 5 languages of German, Italian, French, Spanish and Portuguese.

