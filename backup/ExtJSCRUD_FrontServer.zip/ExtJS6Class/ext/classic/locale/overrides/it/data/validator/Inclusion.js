Ext.define("Ext.locale.it.data.validator.Inclusion", {
    override: "Ext.data.validator.Inclusion",

    message: "Non \u00E8 nell'elenco dei valori consentiti"
});
