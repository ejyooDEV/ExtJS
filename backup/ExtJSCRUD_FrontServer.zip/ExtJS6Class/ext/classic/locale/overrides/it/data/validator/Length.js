Ext.define("Ext.locale.it.data.validator.Length", {
    override: "Ext.data.validator.Length",

    minOnlyMessage: "Lunghezza minima {0}",
    maxOnlyMessage: "Lunghezza massima {0}",
    bothMessage: "Lunghezza compresa tra {0} e {1}"
});
