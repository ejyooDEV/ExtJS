Ext.define("Ext.locale.it.data.validator.Range", {
    override: "Ext.data.validator.Range",

    minOnlyMessage: "Deve essere minimo {0}",
    maxOnlyMessage: "Deve essere massimo {0}",
    bothMessage: "Deve essere compreso tra {0} e {1}",
    nanMessage: "Deve essere un valore numerico"
});
