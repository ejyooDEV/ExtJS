Ext.define("Ext.locale.it.grid.PropertyColumnModel", {
    override: "Ext.grid.PropertyColumnModel",

    nameText: "Nome",
    valueText: "Value",
    dateFormat: "j/m/Y",
    trueText: "vero",
    falseText: "falso"
});
