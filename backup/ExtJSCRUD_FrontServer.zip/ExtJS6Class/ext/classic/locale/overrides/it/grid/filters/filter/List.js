Ext.define("Ext.locale.it.grid.filters.filter.List", {
    override: "Ext.grid.filters.filter.List",

    loadingText: 'Caricamento...'
});
