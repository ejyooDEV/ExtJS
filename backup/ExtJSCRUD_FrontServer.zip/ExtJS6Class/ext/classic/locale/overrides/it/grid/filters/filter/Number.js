Ext.define("Ext.locale.it.grid.filters.filter.Number", {
    override: "Ext.grid.filters.filter.Number",

    emptyText: 'Inserisci il Numero...'
});
