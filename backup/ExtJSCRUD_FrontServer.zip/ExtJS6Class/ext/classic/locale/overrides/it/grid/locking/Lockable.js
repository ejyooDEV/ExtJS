Ext.define("Ext.locale.it.grid.locking.Lockable", {
    override: "Ext.grid.Lockable",

    lockText: "Blocca colonna",
    unlockText: "Sblocca colonna"
});
