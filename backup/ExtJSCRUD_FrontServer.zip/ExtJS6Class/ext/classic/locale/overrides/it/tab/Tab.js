Ext.define("Ext.locale.it.tab.Tab", {
    override: "Ext.tab.Tab",

    closeText: 'Rimuovibile'
});
