Ext.define('Ext.locale.pt_BR.grid.feature.Grouping', {
    override: 'Ext.grid.feature.Grouping',
    emptyGroupText: '(Nenhum)',
    groupByText: 'Agrupar por este campo',
    showGroupsText: 'Mostrar agrupado'
});
