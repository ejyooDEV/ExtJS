Ext.define('Ext.locale.pt_BR.grid.filters.Filters', {
    override: 'Ext.grid.filters.Filters',
    menuFilterText: 'Filtros'
});
