Ext.define('Ext.theme.triton.picker.Date', {
    override: 'Ext.picker.Date',

    footerButtonUI: 'default-toolbar'
});
